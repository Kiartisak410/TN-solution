#!/bin/bash
while true
do
	echo "Looping forever..."
	sleep 1
done
